#!/bin/bash
insmod ax99100_spi.ko
